# How to use it
Clone and run py -2 jemdoc index.jemdoc to get the personal website
It has to be python2 because jemdoc was based on python 2. One can download a python 2 to run the code.
